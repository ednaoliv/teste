
// declara��o de classe
public class Item {
	// primeiro atributo
	private float precoUnitario;
	// segundo atributo
	private String descricao;
	// terceiro atributo
	private String id;
	
	// declara��o do contrutor
	public Item() {
		this.setPrecoUnitario( 100.0f );
		this.setDescricao( "Sem descricao" );
		this.setId( "Sem ID" );
	}
	
	// primeiro metodo acessor (get)
	public float getPrecoUnitario() {
		return this.precoUnitario;
	}
	
	// segundo metodo acessor (get)
	public String getDescricao() {
		return this.descricao;
	}
	
	// terceiro metodo acessor (get)
	public String getId() {
		return this.id;
	}
	
	// primeiro metodo mutante (set)
	public boolean setPrecoUnitario( float preco /*poderia ser precoUnitario*/ ) {
		if( preco < 0 ) {
			return false;
		}
		this.precoUnitario = preco;
		return true;
	}
	
	// segundo metodo mutante (set)
	public void setDescricao( String descricao ) {
		this.descricao = descricao;
	}
	
	// terceiro metodo mutante (set)
	public void setId( String id ) {
		this.id = id;
	}
}
